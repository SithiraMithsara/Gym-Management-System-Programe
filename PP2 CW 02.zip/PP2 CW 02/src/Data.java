public class Data extends Interface {

    int memberID;
    String fstName;
    String lstName;
    String address;

    public void setMemberID(int memberID) {this.memberID = memberID;}
    public void setfstName(String fstName) {this.fstName = fstName;}
    public void setlstName(String lstName) {this.lstName = lstName;}
    public void setAddress(String address) {this.address = address;}
    public int getMemberID() {return memberID;}
    public String getfstName() {return fstName;}
    public String getlstName() {return lstName;}
    public String getAddress() {return address;}

}
